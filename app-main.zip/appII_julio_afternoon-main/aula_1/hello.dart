import 'dart:io';

void main() {
  print('Digite seu nome:');
  String name = stdin.readLineSync()!;
  print('Hello, $name!!!');
}
