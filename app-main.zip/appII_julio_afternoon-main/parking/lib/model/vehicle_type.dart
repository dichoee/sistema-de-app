enum VehicleType{
  motorcycle,
  car
}