import 'package:flutter/material.dart';
import 'package:parking/screens/home/home.dart';

void main() {
  runApp(
    const MaterialApp(
      home: Home(),
      debugShowCheckedModeBanner: false,
    ),
  );
}
