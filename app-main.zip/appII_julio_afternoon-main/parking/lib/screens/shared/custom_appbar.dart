import 'package:flutter/material.dart';

AppBar customAppBar(String appTitle) {
  return AppBar(
    title: Text(appTitle),
    backgroundColor: const Color.fromARGB(255, 117, 117, 117), 
    actions: [
      PopupMenuButton<int>(
        itemBuilder: (context) => [
          PopupMenuItem<int>(
            value: 1,
            child: Container(
              color: Color.fromARGB(255, 117, 117, 117), // Sem const
              padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16), // Sem const
              child: Text(
                'Meu perfil',
                style: TextStyle(color: Colors.white), // Sem const
              ),
            ),
          ),
          PopupMenuItem<int>(
            value: 2,
            child: Container(
              color: Color.fromARGB(255, 117, 117, 117), // Sem const
              padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16), // Sem const
              child: Text(
                'Configurações',
                style: TextStyle(color: Colors.white), // Sem const
              ),
            ),
          ),
        ],
        onSelected: (value) {
          // Adicione a lógica de manipulação para os itens selecionados aqui
        },
      ),
    ],
  );
}

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        appBar: customAppBar('App Title'),
      ),
      debugShowCheckedModeBanner: false,
    ),
  );
}
