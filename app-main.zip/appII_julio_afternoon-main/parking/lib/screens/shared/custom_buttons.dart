// lib/custom_buttons.dart

import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  final String imagePath;
  final VoidCallback onPressed;
  final double width;
  final double height;
  final Color? backgroundColor;
  final BorderRadius? borderRadius;
  final BoxShadow? boxShadow;

  const CustomButton({
    required this.imagePath,
    required this.onPressed,
    required this.width,
    required this.height,
    this.backgroundColor,
    this.borderRadius,
    this.boxShadow,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: backgroundColor ?? Colors.transparent,
          borderRadius: borderRadius ?? BorderRadius.circular(0),
          boxShadow: boxShadow != null ? [boxShadow!] : [],
        ),
        child: ClipRRect(
          borderRadius: borderRadius ?? BorderRadius.circular(0),
          child: Image.asset(
            imagePath,
            fit: BoxFit.cover,
            width: width,
            height: height,
          ),
        ),
      ),
    );
  }
}
