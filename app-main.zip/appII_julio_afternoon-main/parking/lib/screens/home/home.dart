// lib/home.dart

import 'package:flutter/material.dart';
import 'package:parking/model/ticket.dart';
import 'package:parking/model/vacancy.dart';
import 'package:parking/model/vehicle.dart';
import 'package:parking/model/vehicle_type.dart';
import 'package:parking/screens/shared/custom_appbar.dart';
import 'package:parking/screens/shared/custom_buttons.dart'; // Importando o arquivo de botões

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    var corvette = Vehicle(
      licensePlate: 'JUE-0593',
      brand: 'Chevrolet',
      model: 'Corvette',
      vehicleType: VehicleType.car,
    );
    var vacancy = Vacancy(
      number: 1,
      description: 'Vaga 0001',
      vehicleType: VehicleType.car,
    );
    var ticket = Ticket(
      number: 1,
      vacancy: vacancy,
      vehicle: corvette,
      entryTime: TimeOfDay.now(),
    );

    return Scaffold(
      appBar: customAppBar('Parking Control'),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        child: const Icon(Icons.add),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.bottomCenter,
            end: Alignment.topCenter,
            colors: [
              Color.fromARGB(255, 66, 66, 66),
              Color.fromARGB(255, 165, 164, 164),
            ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Image.asset(
                    'assets/car.png',
                    width: 150,
                  ),
                  const SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'malibu',
                        style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                          fontSize: 55, // Aumente o tamanho do texto conforme necessário
                        ),
                      ),
                      Text(
                        'LBT 9327',
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                    ],
                  ),
                ],
              ),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Divider(
                  color: Colors.black,
                  thickness: 2,
                ),
              ),
              Expanded(
                child: Center(
                  child: GridView.count(
                    crossAxisCount: 2, // Dois botões por linha
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    children: [
                      CustomButton(
                        imagePath: 'assets/map.png',
                        width: 15, // Ajuste a largura conforme necessário
                        height: 15, // Ajuste a altura conforme necessário
                        backgroundColor: Colors.blue,
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: BoxShadow(
                          color: Colors.black26,
                          blurRadius: 2,
                          offset: Offset(2, 2),
                        ),
                        onPressed: () {
                          // Ação ao pressionar o botão 1
                          print('Botão 1 Pressionado');
                        },
                      ),
                      CustomButton(
                        imagePath: 'assets/map2.png',
                        width: 150, // Ajuste a largura conforme necessário
                        height: 150, // Ajuste a altura conforme necessário
                        backgroundColor: Colors.green,
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: BoxShadow(
                          color: Colors.black26,
                          blurRadius: 4,
                          offset: Offset(2, 2),
                        ),
                        onPressed: () {
                          // Ação ao pressionar o botão 2
                          print('Botão 2 Pressionado');
                        },
                      ),
                      CustomButton(
                        imagePath: 'assets/pedagio.png',
                        width: 150, // Ajuste a largura conforme necessário
                        height: 150, // Ajuste a altura conforme necessário
                        backgroundColor: Colors.red,
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: BoxShadow(
                          color: Colors.black26,
                          blurRadius: 4,
                          offset: Offset(2, 2),
                        ),
                        onPressed: () {
                          // Ação ao pressionar o botão 3
                          print('Botão 3 Pressionado');
                        },
                      ),
                      CustomButton(
                        imagePath: 'assets/valores.png',
                        width: 150, // Ajuste a largura conforme necessário
                        height: 150, // Ajuste a altura conforme necessário
                        backgroundColor: Colors.yellow,
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: BoxShadow(
                          color: Colors.black26,
                          blurRadius: 4,
                          offset: Offset(2, 2),
                        ),
                        onPressed: () {
                          // Ação ao pressionar o botão 4
                          print('Botão 4 Pressionado');
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
